package com.citi.pojo;

public class Savings extends Account {
	private boolean isSalary;

	public Savings() {
		System.out.println("Default constrcutor of Savings");
	}

	public Savings(int accountNumber, String name, double balance, boolean isSalary) {
		super(accountNumber, name, balance);
		this.isSalary = isSalary;
		System.out.println("Overloaded constrcutor of Savings");
	}

	// if isSalary = true :: balance can be 0
	// if isSalary = false :: balance can be 1500
	public boolean withdraw(double amount) {
		if (amount > 0 && isSalary && getBalance() - amount >= 0) {
			setBalance(getBalance() - amount);
			return true;
		}
		if (amount > 0 && isSalary == false && getBalance() - amount >= 1500) {
			setBalance(getBalance() - amount);
			return true;
		}
		return false;
	}

	public boolean deposit(double amount) {
		return super.deposit(amount);
	}

	public boolean isSalary() {
		return isSalary;
	}

	public void setSalary(boolean isSalary) {
		this.isSalary = isSalary;
	}

	@Override
	public String toString() {
		return "Savings [isSalary=" + isSalary + ", getAccountNumber()=" + getAccountNumber() + ", getName()="
				+ getName() + ", getBalance()=" + getBalance() + "]";
	}

}
