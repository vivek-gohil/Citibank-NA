package com.citi.main;

import com.citi.pojo.Account;

public class AccountMainV1 {
	public static void main(String[] args) {

		System.out.println("Start");
		Account account = new Account();

		// accoun.accountNumber = 101;
		account.setAccountNumber(101);
		account.setName("Vivek Gohil");
		account.setBalance(5000);

		System.out.println("Account Number :: " + account.getAccountNumber());
		System.out.println("Name :: " + account.getName());
		System.out.println("Balance :: " + account.getBalance());
		
		System.out.println("End");
	}
}
