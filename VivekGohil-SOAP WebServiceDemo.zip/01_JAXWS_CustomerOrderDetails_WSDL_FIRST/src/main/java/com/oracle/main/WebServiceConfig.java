package com.oracle.main;

import javax.xml.ws.Endpoint;

import org.apache.cxf.Bus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class WebServiceConfig {

	@Bean
	public Endpoint endpoint(Bus bus) {
		Endpoint endpoint = new EndpointImpl(bus, new CustomerOrdersImpl());
		endpoint.publish("/customerordersservice");
		return endpoint;
	}
}
