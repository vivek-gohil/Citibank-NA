package com.oracle.main;

import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;

import com.borntocode.CustomerOrdersPortType;
import com.borntocode.GetOrdersRequest;
import com.borntocode.GetOrdersResponse;
import com.borntocode.Order;
import com.borntocode.Product;

public class CustomerOrderWSClient {
	public static void main(String[] args) {
		try {
			CustomerOrdersImplService service = new CustomerOrdersImplService(
					new URL("http://localhost:8787/services/customerordersservice?wsdl"));
			CustomerOrdersPortType customerOrdersPortType = service.getCustomerOrdersImplPort();

			GetOrdersRequest request = new GetOrdersRequest();
			request.setCustomerId(BigInteger.valueOf(1));

			GetOrdersResponse response = customerOrdersPortType.getOrders(request);
			List<Order> orders = response.getOrder();

			System.out.println("Number of orders :: " + orders.size());
			for (Order order : orders) {
				System.out.println("OrderID " + order.getId());
				List<Product> products = order.getProduct();
				for (Product product : products) {
					System.out.println("ProductId : " + product.getId());
					System.out.println("Description :" + product.getDescription());
					System.out.println("Quantity " + product.getQuantity());
				}
			}

		} catch (MalformedURLException e) {
			System.out.println(e.getMessage());
		}

	}
}
