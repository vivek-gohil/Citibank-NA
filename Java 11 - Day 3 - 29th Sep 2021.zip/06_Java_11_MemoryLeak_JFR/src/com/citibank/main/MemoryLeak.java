package com.citibank.main;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class MemoryLeak {

	private static BlockingQueue<byte[]> queue = new LinkedBlockingQueue<byte[]>();

	public static void main(String[] args) {
		Runnable producer = () -> {
			while (true) {
				// generate 1 mb of object every 10ms
				queue.offer(new byte[1 * 1024 * 1024]);
				try {
					TimeUnit.MILLISECONDS.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};

		Runnable consumer = () -> {
			while (true) {
				// process data every 100ms
				try {
					queue.take();
					TimeUnit.MILLISECONDS.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};

		// give proper name to the threads
		new Thread(producer, "Producer Thread").start();
		new Thread(consumer, "Consumer Thread").start();
	}
}
