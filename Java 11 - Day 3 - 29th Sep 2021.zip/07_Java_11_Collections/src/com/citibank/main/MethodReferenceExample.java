package com.citibank.main;

public class MethodReferenceExample {

	public static void main(String[] args) {
		printMessage();

		System.out.println("-".repeat(50));

		Thread thread = new Thread(new Runnable() {
			@Override
			public void run() {
				printMessage();
			}
		});

		thread.start();

		System.out.println("-".repeat(50));

		Thread thread2 = new Thread(() -> printMessage());
		thread2.start();

		System.out.println("-".repeat(50));

		Thread thread3 = new Thread(MethodReferenceExample::printMessage); // same as () -> printMessage()
		thread3.start();
	}

	public static void printMessage() {
		System.out.println("Hello from printMessage()");
	}
}
