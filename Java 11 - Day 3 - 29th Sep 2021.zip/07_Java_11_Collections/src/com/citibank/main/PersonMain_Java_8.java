package com.citibank.main;

import java.io.PrintStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

import com.citibank.pojo.Person;

public class PersonMain_Java_8 {

	public static void main(String[] args) {
		List<Person> people = Arrays.asList(new Person("Vivek", "Gohil", 31), new Person("Trupti", "Acharekar", 30),
				new Person("Gurubux", "Gill", 26), new Person("Samarth", "Patil", 10));
		// step 1 :: Sort the list by last name
		Collections.sort(people, (p1, p2) -> p1.getLastName().compareTo(p2.getLastName()));

		// step 2 :: Create method that prints all the elements in the list
		printConditionally(people, p -> true, System.out::println);

		System.out.println("-".repeat(50));
		// step 3 :: Create method that prints all people that have last name begining
		// with G
		printConditionally(people, p -> p.getLastName().startsWith("G"), System.out::println);
		System.out.println("-".repeat(50));

		// step 4 :: Create method that prints all people that have last name ending
		// with L
		printConditionally(people, p -> p.getLastName().endsWith("l"), System.out::println);

	}

	private static void printConditionally(List<Person> people, Predicate<Person> predicate,
			Consumer<Person> consumer) {
		for (Person person : people) {
			if (predicate.test(person))
				consumer.accept(person);
		}
	}
}
