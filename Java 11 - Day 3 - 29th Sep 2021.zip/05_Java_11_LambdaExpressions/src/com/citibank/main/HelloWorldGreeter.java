package com.citibank.main;

public class HelloWorldGreeter implements Greeting {

	@Override
	public void performGreeting() {
		System.out.println("Hello World");
	}

}
