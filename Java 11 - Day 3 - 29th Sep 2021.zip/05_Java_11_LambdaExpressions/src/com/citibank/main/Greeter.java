package com.citibank.main;

public class Greeter {
//	public void greet() {
//		System.out.println("Hello World!");
//	}

	public void greet(Greeting greeting) {
		greeting.performGreeting();
	}

	public static void main(String[] args) {
		Greeter greeter = new Greeter();
		// greeter.greet();

		HelloWorldGreeter helloWorldGreeter = new HelloWorldGreeter();
		greeter.greet(helloWorldGreeter);

		System.out.println("-".repeat(50));

		GoodMorningGreeter goodMorningGreeter = new GoodMorningGreeter();
		greeter.greet(goodMorningGreeter);

		Greeting innerClassGreeting = new Greeting() {
			@Override
			public void performGreeting() {
				System.out.println("Hello World");
			}
		};

		Greeting goodAfternoonGreeting = new Greeting() {
			@Override
			public void performGreeting() {
				System.out.println("Good Afternoon");
			}
		};

		greeter.greet(innerClassGreeting);

		greeter.greet(goodAfternoonGreeting);

		// TypeInference
		Greeting goodEvening = () -> System.out.println("Good Evening");
		greeter.greet(goodEvening);

	}
}
