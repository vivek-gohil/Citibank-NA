package com.citibank.main;

@FunctionalInterface
public interface Greeting {
	public void performGreeting();

	// public void show();
}
