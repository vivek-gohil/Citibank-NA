package com.citibank.main;

public class GoodMorningGreeter implements Greeting {
	@Override
	public void performGreeting() {
		System.out.println("Good Morning");
	}
}
