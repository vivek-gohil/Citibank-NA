package com.citibank.main;


public class LocalVariableMain {
	public static void main(String[] args) {
	}
}
