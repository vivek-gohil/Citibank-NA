package com.citibank.main;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

public class HttpClientEmployeeCRUDMain {
	private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder().version(HttpClient.Version.HTTP_2)
			.connectTimeout(Duration.ofSeconds(10)).build();

	public static void main(String[] args) {

		HttpRequest request = HttpRequest.newBuilder().GET()
				.uri(URI.create("http://localhost:8080/api/employeecrud/employees"))
				.setHeader("User-Agent", "Java 11 Citibank Training Demo").header("Content-Type", "application/json")
				.build();
		try {
			HttpResponse<String> response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
			System.out.println("Status Code :: " + response.statusCode());
			System.out.println("Response Body :: ");
			System.out.println(response.body());
		} catch (IOException | InterruptedException e) {
			System.out.println(e.getMessage());
		}
	}
}
