package com.citibank.main;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

public class HttpClientMain {

	private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder().version(HttpClient.Version.HTTP_2)
			.connectTimeout(Duration.ofSeconds(10)).build();

	public static void main(String[] args) {
		Map<Object, Object> data = new HashMap<Object, Object>();

		data.put("username", "abc");
		data.put("password", "123");
		data.put("timestamp", System.currentTimeMillis());

		System.out.println("POST request url");
//		ofFormData(data);

		HttpRequest request = HttpRequest.newBuilder().POST(ofFormData(data))

				.uri(URI.create("https://httpbin.org/post")).setHeader("User-Agent", "Java 11 Citibank Training Demo")
				.header("Content-Type", "application/x-www-form-urlencoded").build();

		try {
			HttpResponse<String> response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
			System.out.println("Status Code :: " + response.statusCode());
			System.out.println("Response Body :: ");
			System.out.println(response.body());
		} catch (IOException | InterruptedException e) {
			System.out.println(e.getMessage());
		}

	}

	// http://localhost:8080/name=test&id=10
	public static HttpRequest.BodyPublisher ofFormData(Map<Object, Object> data) {
		var builder = new StringBuilder();
		for (Map.Entry<Object, Object> entry : data.entrySet()) {
			if (builder.length() > 0) {
				builder.append("&");
			}
			builder.append(URLEncoder.encode(entry.getKey().toString(), StandardCharsets.UTF_8));
			builder.append("=");
			builder.append(URLEncoder.encode(entry.getValue().toString(), StandardCharsets.UTF_8));
		}
		System.out.println(builder.toString());
		return HttpRequest.BodyPublishers.ofString(builder.toString());
	}

}
