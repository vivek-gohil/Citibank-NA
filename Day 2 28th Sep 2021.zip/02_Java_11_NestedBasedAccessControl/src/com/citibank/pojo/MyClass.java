package com.citibank.pojo;

public class MyClass {
	private String name = "This is sample text message";

	public class NewClass {
		public void printName() {
			System.out.println(name);
		}
	}
}

//After javac MyClass.java, Java compiler created something similar to this.
public class MyClass {
	private String name = "This is sample text message";
	
	String access$000() {
		return name;
	}
}

public class MyClass$NewClass {
	final MyClass obj;
	public void printName() {
		System.out.println(obj.access$000());
	}
}
