package com.citibank.main;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class ReadingWritingMain {
	public static void main(String[] args) {
		try {
			Files.writeString(Paths.get("./data.txt"), "This is sample data", StandardCharsets.UTF_8,
					StandardOpenOption.APPEND);
			System.out.println(Files.readString(Paths.get("./data.txt")));
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
