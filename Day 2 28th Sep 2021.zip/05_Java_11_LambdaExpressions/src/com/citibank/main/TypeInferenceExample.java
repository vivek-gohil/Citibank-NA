package com.citibank.main;

public class TypeInferenceExample {
	public static void main(String[] args) {
//		StringLength stringLength1 = (String text) -> text.length();

		StringLength stringLength2 = (text) -> text.length();

		ArithmaticInterface arithmaticInterface = (num1, num2) -> num1 + num2;

		printCalculation(arithmaticInterface);

		printCalculation((num1, num2) -> num1 + num2);
		printCalculation((num1, num2) -> num1 - num2);
		printCalculation((num1, num2) -> num1 * num2);
		printCalculation((num1, num2) -> num1 / num2);

		// print(stringLength2);

	}

	public static void print(StringLength stringLength) {
		System.out.println("String length :: " + stringLength.getLength("Hi"));
	}

	public static void printCalculation(ArithmaticInterface arithmaticInterface) {
		System.out.println("Result is :: " + arithmaticInterface.calculateresult(10, 2));
	}

	interface StringLength {
		int getLength(String text);
	}

	interface ArithmaticInterface {
		double calculateresult(double num1, double num2);
	}

}
//1. create new interface(ArithmaticInterface) with method(calculateresult) which accept two param as num1 , num2
//2. create new method(printCalculation) which accept interface as param to print the result of calculation
//3. do the below arithmatic operation by supplying the lambda expression as the param the the fucntion
// + , - , * , /
