package com.citibank.main;

//Funcational Interface
public interface Greeting {
	public void performGreeting();
}
