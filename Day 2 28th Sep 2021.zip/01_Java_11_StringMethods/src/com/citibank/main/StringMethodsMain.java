package com.citibank.main;

import java.util.List;
import java.util.stream.Collectors;

public class StringMethodsMain {
	public static void main(String[] args) {
		System.out.println("Main start");

		System.out.println("1. isBlank");
		System.out.println("This instance method returns a boolean value");
		String name = "Citibank";
		System.out.println("Checking if value of name String is blank :: " + name.isBlank()); // false

		System.out.println();
		name = " ";
		System.out.println("Checking if value of name String is blank :: " + name.isBlank()); // false

		name = " ";
		System.out.println("Checking if value of name String is blank :: " + name.isEmpty()); // false);

		System.out.println();

		System.out.println("2. lines");
		System.out.println(
				"This method returns a stream of strings, which is a collection of all substrings split by lines");
		String str = "Vivek\nVikas\nMukul\nChandrakant";
		System.out.println(str);

		System.out.println();

		System.out.println("Collecting the result of above string into a List<String>");
		List<String> nameList = str.lines().collect(Collectors.toList());
		System.out.println(nameList);
		System.out.println("-".repeat(30));
		for (String tempName : nameList) {
			System.out.println(tempName);
		}

		System.out.println();

		System.out.println("3. strip");
		str = " Citibank NA Java 11 ";
		System.out.print("start");
		System.out.print(str);
		System.out.println("end");

		System.out.println();
		System.out.print("start");
		System.out.print(str.strip());
		System.out.println("end");

		System.out.println();
		System.out.println("4. stripLeading and stripTrailing");
		System.out.println("Value of String after calling stripLeading");
		System.out.print("start");
		System.out.print(str.stripLeading());
		System.out.println("end");

		System.out.println();
		System.out.println("Value of String after calling stripTrailing");
		System.out.print("start");
		System.out.print(str.stripTrailing());
		System.out.println("end");

		System.out.println();
		str = "test string\u205F";
		System.out.println(str);
		System.out.println(str.strip());
		System.out.println(str.trim());

		System.out.println("5.repeat");
		str = " Citibank Java 11 Training ";
		System.out.println(str.repeat(3));

		System.out.println("Main end");
	}
}
