package com.citibank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.citibank.pojo.BookIssueDetails;

public class BookIssueDetailsDAO {
	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultset;
	private String sql;
	private int count;
	private String driver = "com.mysql.cj.jdbc.Driver";
	private String user = "root", password = "Bahubali@01";
	private String url = "jdbc:mysql://localhost:3306/lmsdb";
	private List<BookIssueDetails> bookIssueDetails = new ArrayList<BookIssueDetails>();

	public boolean addBookIssueDetails(BookIssueDetails bookIssueDetails) {
		//only database insert query
		return false;
	}

}
