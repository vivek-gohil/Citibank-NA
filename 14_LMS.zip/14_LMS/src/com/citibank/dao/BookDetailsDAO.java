package com.citibank.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.citibank.pojo.BookDetails;
import com.citibank.pojo.BookIssueDetails;

public class BookDetailsDAO {
	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultset;
	private String sql;
	private int count = 0;
	private String driver = "com.mysql.cj.jdbc.Driver";
	private String user = "root", password = "Bahubali@01";
	private String url = "jdbc:mysql://localhost:3306/lmsdb";

	public boolean addNewBook(BookDetails bookDetails) {
		return false;
	}

	public BookDetails getBookDetails(int bookId) {

		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
			sql = "select * from books where book_id=?";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, bookId);
			resultset = preparedStatement.executeQuery();

			if (resultset.next()) {
				BookDetails bookDetails = new BookDetails();
				bookDetails.setBookId(resultset.getInt("book_id"));
				bookDetails.setName(resultset.getString("title"));
				bookDetails.setAuthor(resultset.getString("author"));
				bookDetails.setNumberOfCopyies(resultset.getInt("no_of_copies"));
				bookDetails.setAvailableCount(resultset.getInt("avaliable_count"));

				return bookDetails;
			}
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Exception :: " + e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception :: " + e.getMessage());
			}
		}
		return null;
	}

}
