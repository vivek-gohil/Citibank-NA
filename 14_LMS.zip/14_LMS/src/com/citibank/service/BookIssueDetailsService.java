package com.citibank.service;

import java.util.Date;

import com.citibank.dao.BookDetailsDAO;
import com.citibank.dao.BookIssueDetailsDAO;
import com.citibank.dao.UserDetailsDAO;
import com.citibank.pojo.BookDetails;
import com.citibank.pojo.BookIssueDetails;
import com.citibank.pojo.UserDetails;

public class BookIssueDetailsService {
	private BookIssueDetailsDAO bookIssueDetailsDAO = new BookIssueDetailsDAO();
	private UserDetailsDAO userDetailsDAO = new UserDetailsDAO();
	private BookDetailsDAO bookDetailsDAO = new BookDetailsDAO();
	private Date bookIssueDate;
	private Date bookReturnDate;

	public int issueNewBook(int userId, int bookId) {

		UserDetails userDetails = userDetailsDAO.getUserDetails(userId);
		BookDetails bookDetails = bookDetailsDAO.getBookDetails(bookId);

		// bookIssueDate = check the usertype from user details object and set the
		// issuedate
		// bookIssueDate = check the usertype from user details object and set the
		// return date

		BookIssueDetails bookIssueDetails = new BookIssueDetails(0, bookIssueDate, bookReturnDate, bookDetails,
				userDetails);

		boolean result = bookIssueDetailsDAO.addBookIssueDetails(bookIssueDetails);
		
		//check the result and return the issueSerialNumber
		return 0;
	}
}
