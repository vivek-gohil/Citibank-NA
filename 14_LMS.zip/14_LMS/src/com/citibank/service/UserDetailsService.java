package com.citibank.service;

import com.citibank.dao.UserDetailsDAO;
import com.citibank.pojo.UserDetails;

public class UserDetailsService {
	private UserDetailsDAO userDetailsDAO = new UserDetailsDAO();

	public UserDetails getUserDetails(int userId) {
		UserDetails userDetails = userDetailsDAO.getUserDetails(userId);
		if (userDetails != null) {
			return userDetails;
		}
		return null;
	}
}
