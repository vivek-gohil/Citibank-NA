package com.citibank.service;

import com.citibank.dao.BookDetailsDAO;
import com.citibank.pojo.BookDetails;

public class BookDetailsService {
	private BookDetailsDAO bookDetailsDAO = new BookDetailsDAO();

	public BookDetails getBookDetails(int bookId) {
		BookDetails bookDetails = bookDetailsDAO.getBookDetails(bookId);
		if (bookDetails != null) {
			return bookDetails;
		}
		return null;
	}
}
