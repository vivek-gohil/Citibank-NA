package com.citibank.main;

import com.citibank.model.Address;
import com.citibank.model.Employee;

public class EmployeeMain {

	public static void main(String[] args) {
		System.out.println("Starting Main");

		Address address = new Address("B-212", "Nisarg CHS", "AB Road", "Mumbai", "Maharashtra", 400012, "India");
		Employee employee = new Employee(101, "Vivek Gohil", 1000, address);

		System.out.println(employee);

		System.out.println("Main end");

	}

}
