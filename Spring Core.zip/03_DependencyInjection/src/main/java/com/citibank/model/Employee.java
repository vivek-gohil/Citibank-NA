package com.citibank.model;

//Employee 'has a' Address
public class Employee {
	private int employeeId;
	private String name;
	private double salary;
	private Address residentialAddress;

	public Employee() {
		System.out.println("Default Constructor Of Employee");
	}

	public Employee(int employeeId, String name, double salary, Address residentialAddress) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.salary = salary;
		this.residentialAddress = residentialAddress;
		System.out.println("Overloaded Constructor Of Employee");
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		System.out.println("setEmployeeId(..) " + employeeId);
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println("setName(..)" + name);
		this.name = name;
	}

	public double getSalary() {

		return salary;
	}

	public void setSalary(double salary) {
		System.out.println("getSalary(..) " + salary);
		this.salary = salary;
	}

	public Address getResidentialAddress() {
		System.out.println("getResidentialAddress() called");
		return residentialAddress;
	}

	public void setResidentialAddress(Address residentialAddress) {
		System.out.println("setResidentialAddress(..) called");
		this.residentialAddress = residentialAddress;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + ", salary=" + salary + ", residentialAddress="
				+ residentialAddress + "]";
	}

}
