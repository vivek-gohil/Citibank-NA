package com.citibank.model;

public class Address {
	private String house;
	private String buildingName;
	private String street;
	private String city;
	private String state;
	private int pin;
	private String country;

	public Address() {
		System.out.println("Default Constructor Of Address");
	}

	public Address(String house, String buildingName, String street, String city, String state, int pin,
			String country) {
		this.house = house;
		this.buildingName = buildingName;
		this.street = street;
		this.city = city;
		this.state = state;
		this.pin = pin;
		this.country = country;
		System.out.println("Overloaded Constructor Of Address");
	}

	public String getHouse() {
		return house;
	}

	public void setHouse(String house) {
		System.out.println("setHouse(..) " + house);
		this.house = house;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		System.out.println("setBuildingName(..) " + buildingName);
		this.buildingName = buildingName;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		System.out.println("setStreet(..) "+ street);
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		System.out.println("setCity(..) "+ city);
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		System.out.println("setState(..) " + state);
		this.state = state;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		System.out.println("setPin(..) " + pin);
		this.pin = pin;
	}

	public String getCountry() {

		return country;
	}

	public void setCountry(String country) {
		System.out.println("getCountry(..) " + country);
		this.country = country;
	}

	@Override
	public String toString() {
		return "Address [house=" + house + ", buildingName=" + buildingName + ", street=" + street + ", city=" + city
				+ ", state=" + state + ", pin=" + pin + ", country=" + country + "]";
	}

}
