package com.citibank.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class DisplayServlet
 */
@WebServlet("/DisplayServlet")
public class DisplayServlet extends HttpServlet {
	private String name;
	private String address;
	private PrintWriter out;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		out = response.getWriter();
		HttpSession httpSession = request.getSession();
		name = httpSession.getAttribute("name").toString();
		address = httpSession.getAttribute("address").toString();
		
		out.println("<h1>Name :: " + name+"</h1>");
		out.println("Address :: " + address);
	}

}
