package com.citibank.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PageOneServlet
 */
@WebServlet("/PageOneServlet")
public class PageOneServlet extends HttpServlet {

	private PrintWriter out;
	private String message;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		out = response.getWriter();
		out.println("doGet() of PageOneServlet");
		message = request.getParameter("txtMessage");
		out.println("Message :: " + message);
		if (request.getAttribute("optional") != null) {
			out.println(request.getAttribute("optional"));
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		out = response.getWriter();
		out.println("doPost() of PageOneServlet");
		message = request.getParameter("txtMessage");
		out.println("Message :: " + message);
		if (request.getAttribute("optional") != null) {
			out.println(request.getAttribute("optional"));
		}
	}

}
