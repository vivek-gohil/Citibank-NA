package com.citibank.pojo;

public class UserDetails {
	private int userId;
	private String name;
	private String type;
	private int numberOfBooksIssue;

	public UserDetails() {
		// TODO Auto-generated constructor stub
	}

	public UserDetails(int userId, String name, String type, int numberOfBooksIssue) {
		super();
		this.userId = userId;
		this.name = name;
		this.type = type;
		this.numberOfBooksIssue = numberOfBooksIssue;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getNumberOfBooksIssue() {
		return numberOfBooksIssue;
	}

	public void setNumberOfBooksIssue(int numberOfBooksIssue) {
		this.numberOfBooksIssue = numberOfBooksIssue;
	}

	@Override
	public String toString() {
		return "UserDetails [userId=" + userId + ", name=" + name + ", type=" + type + ", numberOfBooksIssue="
				+ numberOfBooksIssue + "]";
	}

}
