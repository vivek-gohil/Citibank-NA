package com.citibank.pojo;

public class BookDetails {
	private int bookId;
	private String name;
	private String author;
	private int numberOfCopyies;
	private int availableCount;

	public BookDetails() {
		// TODO Auto-generated constructor stub
	}

	public BookDetails(int bookId, String name, String author, int numberOfCopyies, int availableCount) {
		super();
		this.bookId = bookId;
		this.name = name;
		this.author = author;
		this.numberOfCopyies = numberOfCopyies;
		this.availableCount = availableCount;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getNumberOfCopyies() {
		return numberOfCopyies;
	}

	public void setNumberOfCopyies(int numberOfCopyies) {
		this.numberOfCopyies = numberOfCopyies;
	}

	public int getAvailableCount() {
		return availableCount;
	}

	public void setAvailableCount(int availableCount) {
		this.availableCount = availableCount;
	}

	@Override
	public String toString() {
		return "BookDetails [bookId=" + bookId + ", name=" + name + ", author=" + author + ", numberOfCopyies="
				+ numberOfCopyies + ", availableCount=" + availableCount + "]";
	}

}
