package com.citibank.pojo;

import java.time.LocalDate;
import java.util.Date;

public class BookIssueDetails {
	private int bookIssueId;
	private LocalDate dateOfIssue;
	private LocalDate dateOfReturn;
	private BookDetails bookDetails;
	private UserDetails userDetails;

	public BookIssueDetails(int bookIssueId, LocalDate dateOfIssue, LocalDate dateOfReturn, BookDetails bookDetails,
			UserDetails userDetails) {
		super();
		this.bookIssueId = bookIssueId;
		this.dateOfIssue = dateOfIssue;
		this.dateOfReturn = dateOfReturn;
		this.bookDetails = bookDetails;
		this.userDetails = userDetails;
	}

	public int getBookIssueId() {
		return bookIssueId;
	}

	public void setBookIssueId(int bookIssueId) {
		this.bookIssueId = bookIssueId;
	}

	public LocalDate getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(LocalDate dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public LocalDate getDateOfReturn() {
		return dateOfReturn;
	}

	public void setDateOfReturn(LocalDate dateOfReturn) {
		this.dateOfReturn = dateOfReturn;
	}

	public BookDetails getBookDetails() {
		return bookDetails;
	}

	public void setBookDetails(BookDetails bookDetails) {
		this.bookDetails = bookDetails;
	}

	public UserDetails getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}

	@Override
	public String toString() {
		return "BookIssueDetails [bookIssueId=" + bookIssueId + ", dateOfIssue=" + dateOfIssue + ", dateOfReturn="
				+ dateOfReturn + ", bookDetails=" + bookDetails + ", userDetails=" + userDetails + "]";
	}

}
