package com.citibank.main;

import java.util.Scanner;

import com.citibank.pojo.BookDetails;
import com.citibank.pojo.UserDetails;
import com.citibank.service.BookDetailsService;
import com.citibank.service.BookIssueDetailsService;
import com.citibank.service.UserDetailsService;

public class LMSMain {
	public static void main(String[] args) {
		int mainMenuChoice;
		int subMenueChoice;
		int userId;
		int bookId;
		int issueSerialNumber;
		UserDetails userDetails;
		BookDetails bookDetails;
		UserDetailsService userDetailsService = new UserDetailsService();
		BookDetailsService bookDetailsService = new BookDetailsService();
		BookIssueDetailsService bookIssueDetailsService = new BookIssueDetailsService();

		Scanner scanner = new Scanner(System.in);

		System.out.println("Menu");
		System.out.println("1.Masters");
		System.out.println("2.Transaction");
		System.out.println("Enter your choice");
		mainMenuChoice = scanner.nextInt();

		if (mainMenuChoice == 1) {
			System.out.println("Menu");
			System.out.println("1.Add Book");
			System.out.println("2.Add Member");
			System.out.println("Enter your choice");
			subMenueChoice = scanner.nextInt();

		} else if (mainMenuChoice == 2) {
			System.out.println("Menu");
			System.out.println("1.Issue Book");
			System.out.println("2.Return Book");
			System.out.println("Enter your choice");
			subMenueChoice = scanner.nextInt();

			switch (subMenueChoice) {
			case 1:
				System.out.println("Enter UserId");
				userId = scanner.nextInt();
				userDetails = userDetailsService.getUserDetails(userId);
				if (userDetails != null) {
					System.out.println("Name :: " + userDetails.getName());
					System.out.println("Member Type :: " + userDetails.getType());
					System.out.println("Number of books issued :: " + userDetails.getNumberOfBooksIssue());
					if (userDetailsService.userDetailsValidation(userDetails)) {
						System.out.println("Enter Book Code");
						bookId = scanner.nextInt();
						bookDetails = bookDetailsService.getBookDetails(bookId);
						if (bookDetails != null) {
							System.out.println("Book Title :: " + bookDetails.getName());
							System.out.println("Author :: " + bookDetails.getAuthor());
							System.out.println("Available Count :: " + bookDetails.getAvailableCount());
							if (bookDetailsService.bookValidation(bookDetails)) {
								issueSerialNumber = bookIssueDetailsService.issueNewBook(userDetails, bookDetails);
								if (issueSerialNumber != 0) {
									System.out.println("Book Issued Successfully!");
									System.out.println("Issue Serial Number :: " + issueSerialNumber);
								}
							} else {
								System.out.println("Cannot issue this book as selected book is not issuable!");
							}

						} else {
							System.out.println("Invalid Book Details!");
						}
					} else {
						System.out.println("Max book issue limit is reached!");
					}
				} else {
					System.out.println("Invalid User!!");
				}
				break;

			default:
				break;
			}

		} else {
			System.out.println("Invalid Choice");
		}

	}
}
