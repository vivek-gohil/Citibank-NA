package com.citibank.service;

import com.citibank.dao.UserDetailsDAO;
import com.citibank.pojo.UserDetails;

public class UserDetailsService {
	private UserDetailsDAO userDetailsDAO = new UserDetailsDAO();
	private int numberOfBooksIssuedCount;

	public UserDetails getUserDetails(int userId) {
		UserDetails userDetails = userDetailsDAO.getUserDetails(userId);
		if (userDetails != null) {
			return userDetails;
		}
		return null;
	}

	public boolean userDetailsValidation(UserDetails userDetails) {
		if (userDetails.getType().equals("faculty")) {
			numberOfBooksIssuedCount = userDetails.getNumberOfBooksIssue();
			if (numberOfBooksIssuedCount < 25) {
				return true;
			}
		}
		if (userDetails.getType().equals("student")) {
			if (numberOfBooksIssuedCount < 3) {
				return true;
			}
		}
		return false;
	}
}
