package com.citibank.service;

import java.time.LocalDate;
import java.util.Date;

import com.citibank.dao.BookDetailsDAO;
import com.citibank.dao.BookIssueDetailsDAO;
import com.citibank.dao.UserDetailsDAO;
import com.citibank.pojo.BookDetails;
import com.citibank.pojo.BookIssueDetails;
import com.citibank.pojo.UserDetails;

public class BookIssueDetailsService {
	private BookIssueDetailsDAO bookIssueDetailsDAO = new BookIssueDetailsDAO();
	private UserDetailsDAO userDetailsDAO = new UserDetailsDAO();
	private BookDetailsDAO bookDetailsDAO = new BookDetailsDAO();
	private LocalDate bookIssueDate;
	private LocalDate bookReturnDate;
	private int bookIssueSerialNumber;

	public int issueNewBook(UserDetails userDetails, BookDetails bookDetails) {
		bookIssueDate = LocalDate.now();
		bookReturnDate = LocalDate.now();
		bookIssueSerialNumber = bookIssueDetailsDAO.getIssueSerialNumber();
		if (userDetails.getType().equals("student")) {
			bookReturnDate = bookIssueDate.plusDays(10);
		}
		if (userDetails.getType().equals("faculty")) {
			bookReturnDate = bookIssueDate.plusDays(90);
		}
		if (bookIssueSerialNumber != 0) {
			bookIssueSerialNumber = bookIssueSerialNumber + 1;
			BookIssueDetails bookIssueDetails = new BookIssueDetails(bookIssueSerialNumber, bookIssueDate,
					bookReturnDate, bookDetails, userDetails);
			if (bookIssueDetailsDAO.addBookIssueDetails(bookIssueDetails)) {
				if (bookDetailsDAO.updateBookCount(bookDetails.getBookId())) {
					if (userDetailsDAO.updateNumberOfBooksIssued(userDetails.getUserId())) {
						return bookIssueDetails.getBookIssueId();
					}
				}
			}
		}
		return 0;
	}
}
