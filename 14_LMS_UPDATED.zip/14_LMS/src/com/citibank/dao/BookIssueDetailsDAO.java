package com.citibank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.citibank.pojo.BookIssueDetails;

public class BookIssueDetailsDAO {
	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultset;
	private String sql;
	private int count;
	private String driver = "com.mysql.cj.jdbc.Driver";
	private String user = "root", password = "Bahubali@01";
	private String url = "jdbc:mysql://localhost:3306/lmsdb";

	public boolean addBookIssueDetails(BookIssueDetails bookIssueDetails) {
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
			sql = "insert into book_issues values(?,?,?,?,?)";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, bookIssueDetails.getBookIssueId());
			preparedStatement.setDate(2, Date.valueOf(bookIssueDetails.getDateOfIssue()));
			preparedStatement.setDate(3, Date.valueOf(bookIssueDetails.getDateOfReturn()));
			preparedStatement.setInt(4, bookIssueDetails.getBookDetails().getBookId());
			preparedStatement.setInt(5, bookIssueDetails.getUserDetails().getUserId());
			count = preparedStatement.executeUpdate();

			if (count > 0)
				return true;
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Exception :: " + e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception :: " + e.getMessage());
			}
		}
		return false;
	}

	public int getIssueSerialNumber() {
		// select max(book_issue_id) from book_issues;
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
			sql = "select max(book_issue_id) from book_issues";
			preparedStatement = connection.prepareStatement(sql);
			resultset = preparedStatement.executeQuery();

			if (resultset.next()) {
				int bookIssueId = resultset.getInt("max(book_issue_id)");
				return bookIssueId;
			}
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Exception :: " + e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception :: " + e.getMessage());
			}
		}
		return 0;
	}

}
