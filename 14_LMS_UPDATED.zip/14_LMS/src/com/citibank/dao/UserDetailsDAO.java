package com.citibank.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.citibank.pojo.BookDetails;
import com.citibank.pojo.UserDetails;

public class UserDetailsDAO {
	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultset;
	private String sql;
	private int numberOfBooksIssuedCount;
	private String driver = "com.mysql.cj.jdbc.Driver";
	private String user = "root", password = "Bahubali@01";
	private String url = "jdbc:mysql://localhost:3306/lmsdb";

	public boolean addNewUser(UserDetails details) {
		return false;
	}

	public UserDetails getUserDetails(int userId) {
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
			sql = "select * from members where member_id=?";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, userId);
			resultset = preparedStatement.executeQuery();

			if (resultset.next()) {
				UserDetails userDetails = new UserDetails();
				userDetails.setUserId(resultset.getInt("member_id"));
				userDetails.setName(resultset.getString("member_name"));
				userDetails.setType(resultset.getString("member_type"));
				userDetails.setNumberOfBooksIssue(resultset.getInt("no_of_books_issued"));

				return userDetails;
			}
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Exception :: " + e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception :: " + e.getMessage());
			}
		}
		return null;
	}

	public boolean updateNumberOfBooksIssued(int userId) {
		UserDetails userDetails = getUserDetails(userId);
		if (userDetails != null) {
			numberOfBooksIssuedCount = userDetails.getNumberOfBooksIssue() + 1;
			try {
				Class.forName(driver);
				connection = DriverManager.getConnection(url, user, password);
				sql = "update members set no_of_books_issued=? where member_id=?";
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setInt(1, numberOfBooksIssuedCount);
				preparedStatement.setInt(2, userId);

				int count = preparedStatement.executeUpdate();

				if (count > 0) {
					return true;
				}

			} catch (ClassNotFoundException | SQLException e) {
				System.out.println("Exception :: " + e.getMessage());
			} finally {
				try {
					connection.close();
				} catch (SQLException e) {
					System.out.println("Exception :: " + e.getMessage());
				}
			}
		}
		return false;
	}

}
