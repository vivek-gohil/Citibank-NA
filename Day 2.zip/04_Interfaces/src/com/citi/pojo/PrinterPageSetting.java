package com.citi.pojo;

public interface PrinterPageSetting {
	void setPageSize();

	public default void displayInfo() {
		System.out.println("This is displayInfo of printPageSetting");
	}
}
