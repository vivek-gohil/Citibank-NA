package com.citi.pojo;

public interface PrinterDriver {
	public abstract void print();
}
