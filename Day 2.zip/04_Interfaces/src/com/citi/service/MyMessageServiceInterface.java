package com.citi.service;

public interface MyMessageServiceInterface {
	void sendMessage(String to, String from, String message);
}
