package com.citi.service;

public class SMSMessageService implements MyMessageServiceInterface {
	public void sendMessage(String to, String from, String message) {
		System.out.println("Sending SMS to :: " + to + " From :: " + from + " Message :: " + message);
	}
}
