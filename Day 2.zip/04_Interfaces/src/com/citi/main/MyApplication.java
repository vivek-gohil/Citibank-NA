package com.citi.main;

import com.citi.pojo.HP3536;

public class MyApplication {
	public static void main(String[] args) {
		HP3536 hp3536 = new HP3536();
		hp3536.displayInfo();
	}
}
