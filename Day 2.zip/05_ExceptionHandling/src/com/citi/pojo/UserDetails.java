package com.citi.pojo;

import java.util.InputMismatchException;
import java.util.Scanner;

public class UserDetails {
	private int[] userId = new int[5];

	public void accept() {
		Scanner scanner = new Scanner(System.in);
		try {
			for (int i = 0; i <= userId.length; i++) {
				System.out.println("Enter userid :: " + (i + 1));
				userId[i] = scanner.nextInt();
			}
		} catch (IndexOutOfBoundsException | InputMismatchException e) {
			System.out.println(e.getMessage());
		} finally {
			scanner.close();
		}
	}

	public void display() {
		for (int i : userId) {
			System.out.println(i);
		}
	}

}
