package com.citi.exception;

public class InvalidProductPriceException extends Exception {
	public String getMessage() {
		return "Invalid Product Price, Please enter price > 0";
	}
}
