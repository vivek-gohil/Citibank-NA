package com.citi.main;

import com.citi.pojo.UserDetails;

public class UserMain {
	public static void main(String[] args) {
		UserDetails details = new UserDetails();
		details.accept();
		details.display();
	}
}
