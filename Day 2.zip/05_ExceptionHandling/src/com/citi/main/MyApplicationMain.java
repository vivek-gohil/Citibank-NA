package com.citi.main;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MyApplicationMain {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		int age = 0;
		try {
			System.out.println("Enter your age");
			age = scanner.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("Invalid Input!!");
		}
		System.out.println("Age entered by user :: " + age);
	}
}
