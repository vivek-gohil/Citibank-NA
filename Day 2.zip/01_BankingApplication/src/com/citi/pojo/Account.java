package com.citi.pojo;

//Generalization
public abstract class Account {
	// instance level variable
	private int accountNumber;
	private static int accountNumberGenerator = 100;
	private String name;
	private double balance;

	// default constrcutor
	public Account() {
		System.out.println("Default constrcutor of Account");
	}

	// overloaded constrcutor
	public Account(int accountNumber, String name, double balance) {
		accountNumberGenerator++;
		this.accountNumber = accountNumberGenerator;
		this.name = name;
		this.balance = balance;
		System.out.println("Overloaded constrcutor of Account");
	}

	public abstract boolean withdraw(double amount);

	public abstract boolean deposit(double amount);

	// getter setters
	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

}
