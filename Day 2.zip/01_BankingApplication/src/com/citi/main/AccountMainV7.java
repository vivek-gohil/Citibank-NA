package com.citi.main;

import java.util.Scanner;

import com.citi.pojo.Account;
import com.citi.pojo.Current;
import com.citi.pojo.Savings;

public class AccountMainV7 {
	public static void main(String[] args) {
		Account account1 = new Current(0, "Vivek", 1000, 10000);
		System.out.println(account1);
		
		Account account2 = new Current(0, "Vivek", 1000, 10000);
		System.out.println(account2);
		
		Account account3 = new Current(0, "Vivek", 1000, 10000);
		System.out.println(account3);
	}
}
