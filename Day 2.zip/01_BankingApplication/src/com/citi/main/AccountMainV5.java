package com.citi.main;

import java.util.Scanner;

import com.citi.pojo.Account;
import com.citi.pojo.Current;
import com.citi.pojo.Savings;

public class AccountMainV5 {
	public static void main(String[] args) {
		int accountNumber;
		String name;
		double balance;
		int choice;
		double amount;
		String continueChoice;
		double overdraftBalance;
		int accountChoice;
		String accountTypeChoice;

		Scanner scanner = new Scanner(System.in);
		Account account = null;

		System.out.println("Menu");
		System.out.println("1. Savings");
		System.out.println("2. Current");
		System.out.println("Enter your choice");
		accountChoice = scanner.nextInt();

		System.out.println("Enter account number");
		accountNumber = scanner.nextInt();

		scanner.nextLine();

		System.out.println("Enter Name");
		name = scanner.nextLine();

		System.out.println("Enter Balance");
		balance = scanner.nextDouble();

		switch (accountChoice) {
		case 1:
			System.out.println("do you want to open Salary account?");
			accountTypeChoice = scanner.next();

			if (accountTypeChoice.equals("yes")) {
				account = new Savings(accountNumber, name, balance, true);
			} else {
				account = new Savings(accountNumber, name, balance, false);
			}
			System.out.println("Account Details");
			System.out.println("Account Number :: " + accountNumber + "Name :: " + name + " balance :: " + balance);
			break;
		case 2:
			System.out.println("Enter Overdraft balance");
			overdraftBalance = scanner.nextDouble();

			account = new Current(accountNumber, name, balance, overdraftBalance);
			System.out.println("Account Details");
			System.out.println("Account Number :: " + accountNumber + "Name :: " + name + " balance :: " + balance
					+ " OverdraftBalance :: " + overdraftBalance);
			break;
		default:
			System.out.println("Invalid Choice");
			System.exit(0);
			break;
		}

		do {
			System.out.println("Menu");
			System.out.println("1. Withdraw");
			System.out.println("2. Deposit");
			System.out.println("3. Check Balance and overdraft balance");

			System.out.println("Enter your choice");
			choice = scanner.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter amount to withdraw");
				amount = scanner.nextDouble();
				//dynamic binding - Polymorphism
				if (account.withdraw(amount)) {
					System.out.println("Transaction Success!!");
				} else {
					System.out.println("Transaction Failed!!");
				}
				break;
			case 2:
				System.out.println("Enter amount to deposit");
				amount = scanner.nextDouble();
				if (account.deposit(amount)) {
					System.out.println("Transaction Success!!");
				} else {
					System.out.println("Transaction Failed!!");
				}
				break;
			case 3:
				System.out.println("Balance :: " + account.getBalance());
				if (account instanceof Current) {
					Current current = (Current) account;
					System.out.println("Overdraft Balance :: " + current.getOverdraftBalance());
				}
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}
			System.out.println("Do you want to continue?");
			continueChoice = scanner.next();
		} while (continueChoice.equals("yes"));
		System.out.println("Thank you for banking with us :)");
	}
}
