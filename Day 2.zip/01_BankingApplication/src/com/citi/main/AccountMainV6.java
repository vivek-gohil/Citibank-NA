package com.citi.main;

import com.citi.pojo.Account;
import com.citi.pojo.Current;
import com.citi.pojo.Savings;

public class AccountMainV6 {
	public static void main(String[] args) {
		Current current = new Current(101, "Vivek Gohil", 1000, 50000);
		System.out.println(current);

		System.out.println("---------------------------------------");

		Savings savings = new Savings(101, "Trupti Acharekar", 1000, true);
		System.out.println(savings);

		System.out.println("---------------------------------------");

		Account account;
		account = new Account(101, "Test", 1000);

	}
}
