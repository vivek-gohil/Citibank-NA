package com.citi.pojo;

public class Foo {

	static int x = 10;
	static int y = 10;

	static {
		System.out.println("Static block called");
	}

	public Foo() {
		System.out.println("Default constrcutor called");
	}

	public static void display() {
		System.out.println(x);
		System.out.println(y);
		x++;
		y++;
		System.out.println(x);
		System.out.println(y);
	}
}
