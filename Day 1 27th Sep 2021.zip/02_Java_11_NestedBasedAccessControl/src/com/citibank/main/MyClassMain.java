package com.citibank.main;

public class MyClassMain {
	public static void main(String[] args) {
		System.out.println("Main is running");
	}
}
