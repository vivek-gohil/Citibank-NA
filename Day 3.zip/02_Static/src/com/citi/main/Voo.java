package com.citi.main;

import com.citi.pojo.Foo;

public class Voo {
	public static void main(String[] args) throws ClassNotFoundException {
		System.out.println("Start");
		Class.forName("com.citi.pojo.Foo");
		System.out.println("End");
	}
}
