package com.citi.main;

import com.citi.pojo.MyClass;

public class MyClassMain {

	public static void main(String[] args) {
		//Integer is a wrapper class 
		MyClass<Integer> classInt = new MyClass<Integer>();
		classInt.setVar(10);
		classInt.display();

		MyClass<String> classStr = new MyClass<String>();
		classStr.setVar("Hello");
		classStr.display();
	}

}
