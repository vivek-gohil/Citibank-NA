package com.citi.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

import com.citi.pojo.Employee;

public class CollectionMain {

	public static void main(String[] args) {
		System.out.println("Collections Examples");
		System.out.println("1. ArrayList");
		List<String> nameList = new ArrayList<String>();
		// ArrayList<String> nameList = new ArrayList<String>();
		nameList.add("Vivek");
		nameList.add("Harini");
		nameList.add("Aman");
		nameList.add("Abhinav");
		nameList.add("Aman");
		nameList.add("Harini");
		nameList.add("Naveen");
		System.out.println(nameList);
		System.out.println("Index of value : Abhinav :: " + nameList.indexOf("Abhinav"));
		System.out.println("--------------------------------");
		System.out.println("using for loop");
		for (String name : nameList) {
			System.out.println(name);
		}
		System.out.println();

		System.out.println("2. HashSet");
		Set<Integer> numberSet = new HashSet<Integer>();
		numberSet.add(19323);
		numberSet.add(12097);
		numberSet.add(23212);
		numberSet.add(98099);
		numberSet.add(23212);
		numberSet.add(12097);
		System.out.println(numberSet);
		System.out.println("--------------------------------");
		System.out.println("using for loop");
		for (int i : numberSet) {
			System.out.println(i);
		}

		System.out.println();

		Set<Employee> employeeSet = new HashSet<Employee>();

//		Employee employee1 = new Employee(101, "Vivek", 1000);
//		System.out.println("employee1 hashCode :: " + employee1.hashCode());
		employeeSet.add(new Employee(101, "Vivek", 1000));

//		Employee employee2 = new Employee(102, "Kirti", 1000);
//		System.out.println("employee2 hashCode :: " + employee2.hashCode());
		employeeSet.add(new Employee(102, "Kirti", 1000));

//		Employee employee3 = new Employee(103, "Sai Chitti Subrahmanyam V", 1000);
//		System.out.println("employee3 hashCode :: " + employee3.hashCode());
		employeeSet.add(new Employee(103, "Sai Chitti Subrahmanyam V", 1000));

//		Employee employee4 = new Employee(101, "Vivek", 1000);
//		System.out.println("employee4 hashCode :: " + employee4.hashCode());
		employeeSet.add(new Employee(101, "Vivek", 1000));

//		Employee employee5 = new Employee(104, "Bhargavi", 1000);
//		System.out.println("employee5 hashCode :: " + employee5.hashCode());
		employeeSet.add(new Employee(104, "Bhargavi", 1000));

//		Employee employee6 = new Employee(102, "Kirti", 1000);
//		System.out.println("employee6 hashCode :: " + employee6.hashCode());
		employeeSet.add(new Employee(102, "Kirti", 1000));

		System.out.println(employeeSet);
		System.out.println("--------------------------------");
		System.out.println("using for loop");
		for (Employee e : employeeSet) {
			System.out.println(e);
		}

		System.out.println();
		SortedSet<Integer> numbersSet = new TreeSet<Integer>();
		numbersSet.add(10);
		numbersSet.add(24);
		numbersSet.add(1);
		numbersSet.add(20);
		numbersSet.add(24);
		numbersSet.add(1);

		System.out.println(numbersSet);
		System.out.println("--------------------------------");
		System.out.println("using for loop");
		for (Integer i : numbersSet) {
			System.out.println(i);
		}

		System.out.println();
		System.out.println("HashMap");
		Map<Integer, String> userMap = new HashMap<Integer, String>();
		userMap.put(10111, "Vivek");
		userMap.put(10431, "Vivek");
		userMap.put(10232, "Vivek");
		userMap.put(10321, "Vivek");
		userMap.put(10512, "Vivek");

		System.out.println(userMap);
		System.out.println("--------------------------------");
		System.out.println("using for loop");
		for (Integer i : userMap.keySet()) {
			System.out.println("Key :: " + i);
			System.out.println("Value :: " + userMap.get(i));
		}

		System.out.println();
		System.out.println("TreeMap");
		SortedMap<Integer, String> productMap = new TreeMap<Integer, String>();
		productMap.put(101, "Nirma");
		productMap.put(99, "Lux");
		productMap.put(11, "Santoor");
		productMap.put(102, "Dove");
		productMap.put(102, "Liril");

		System.out.println(productMap);
		System.out.println("--------------------------------");
		System.out.println("using for loop");
		for (Integer i : productMap.keySet()) {
			System.out.println("Key :: " + i);
			System.out.println("Value :: " + productMap.get(i));
		}

		SortedMap<Integer, Employee> empMap = new TreeMap<Integer, Employee>();
		Employee e1 = new Employee(101, "Test1", 1000);
		Employee e2 = new Employee(112, "Test2", 1000);
		Employee e3 = new Employee(103, "Test3", 1000);

		empMap.put(e1.getEmployeeId(), e1);
		empMap.put(e2.getEmployeeId(), e2);
		empMap.put(e3.getEmployeeId(), e3);

		System.out.println(empMap);
		System.out.println("--------------------------------");
		System.out.println("using for loop");
		for (Integer i : empMap.keySet()) {
			System.out.println("Key :: " + i);
			System.out.println("Value :: " + empMap.get(i));
		}

	}

}
