package com.citi.pojo;

public class MyClass<T> {
	private T var;

	public void setVar(T var) {
		this.var = var;
	}

	public void display() {
		System.out.println("Value of your variable is :: " + var);
	}
}
