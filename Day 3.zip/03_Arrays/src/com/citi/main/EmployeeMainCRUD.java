package com.citi.main;

import java.util.ArrayList;

import com.citi.pojo.Employee;

public class EmployeeMainCRUD {

	public static void main(String[] args) {
		
		ArrayList<E>
		int size = 100;

		Employee[] employees = new Employee[size];
		int arrayIndex = 0;

		addNewEmployee(new Employee(101, "Test1", 1000));
		addNewEmployee(new Employee(102, "Test2", 2000));
		addNewEmployee(new Employee(103, "Test3", 3000));
		addNewEmployee(new Employee(104, "Test4", 3000));
		addNewEmployee(new Employee(105, "Test5", 3000));

		System.out.println();

		for (int i = 0; i < arrayIndex; i++) {
			System.out.println(employees[i]);
		}

		System.out.println();

		Employee e = new Employee(102, "New Name", 2500);
		updatedEmployee(e);
		for (int i = 0; i < arrayIndex; i++) {
			System.out.println(employees[i]);
		}

		System.out.println();

		e = getEmployeeByEmployeeId(103);
		System.out.println(e);

		System.out.println();

		deleteEmployeeByEmployeeId(102);

		for (int i = 0; i < arrayIndex; i++) {
			System.out.println(employees[i]);
		}

	}

	public static void addNewEmployee(Employee employee) {
		employees[arrayIndex] = employee;
		arrayIndex++;
	}

	public static boolean updatedEmployee(Employee employee) {
		for (int i = 0; i < arrayIndex; i++) {
			Employee emp = employees[i];
			if (emp.getEmployeeId() == employee.getEmployeeId()) {
				emp.setName(employee.getName());
				emp.setSalary(employee.getSalary());
				return true;
			}
		}
		return false;
	}

	public static int getEmployeeIndex(int employeeId) {
		for (int i = 0; i < arrayIndex; i++) {
			Employee emp = employees[i];
			if (emp.getEmployeeId() == employeeId) {
				return i;
			}
		}
		return -1;
	}

	public static boolean deleteEmployeeByEmployeeId(int employeeId) {

		int index = getEmployeeIndex(employeeId);
		if (index != -1) {
			// System.out.println(index);

			while (index < arrayIndex - 1) {
				employees[index] = employees[index + 1];
				index++;
			}
			employees[arrayIndex] = null;
			arrayIndex--;
			return true;
		}
		return false;

	}

	public static Employee getEmployeeByEmployeeId(int employeeId) {
		for (int i = 0; i < arrayIndex; i++) {
			Employee emp = employees[i];
			if (emp.getEmployeeId() == employeeId) {
				return emp;
			}
		}
		return null;
	}

	public static Employee[] getAllEmployees() {
		return employees;
	}
}
