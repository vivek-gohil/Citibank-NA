package com.citi.main;

import java.util.Scanner;

import com.citi.pojo.Employee;

public class EmployeeMain {

	public static void main(String[] args) {
		Employee[] employees = new Employee[5];
		Scanner scanner = new Scanner(System.in);
		int employeeId;
		String name;
		double salary;

		for (int i = 0; i < employees.length; i++) {
			System.out.println("Enter employeeId");
			employeeId = scanner.nextInt();
			System.out.println("Enter Name");
			name = scanner.next();
			System.out.println("Enter salary");
			salary = scanner.nextDouble();
			Employee employee = new Employee(employeeId, name, salary);
			employees[i] = employee;
		}

		System.out.println("--------------------------------------");

		for (Employee employee : employees) {
			System.out.println(employee);
		}
		
		//Menu
		//1. Add new employee
		//2. Update Name and salary by employeeid
		//3. Delete employee by employeeId
		//4. Get Single employee by employeeId
		//5. Get all employees
		
		//enter your choice
		// ....
		
		//do you want to continue?
		//if yes print menu
		
	}
	
	//add new employee in array 
	
	//update existing employee name and salary employeeid
	
	//remove employee from array by employeeId
	
	//retrive single employee by employeeId
	
	//retrive all employees from employee array
}
