package com.citi.main;

import java.util.Arrays;

public class ArraysMain {

	public static void main(String[] args) {
		int[] numbers = new int[] { 8, 65, 23, 51, 28, 54 };
		int sum = 0, min = 0, max = 0, avg = 0, count = 0;

		// for each loop : Read only loop
		min = numbers[0];
		max = numbers[0];
		for (int i : numbers) {
			sum += i;
			if (i < min) {
				min = i;
			}
			if (i > max) {
				max = i;
			}
		}
		avg = sum / numbers.length;
		System.out.println("Using Code");
		System.out.println("Sum of all elements :: " + sum);
		System.out.println("Min of all elements :: " + min);
		System.out.println("Max of all elements :: " + max);
		System.out.println("Avg of all elements :: " + avg);

		System.out.println();
		System.out.println("---------------------------------");
		System.out.println();

		System.out.println("Using Arrays utility class");
		Arrays.sort(numbers);

		for (int i : numbers) {
			System.out.println(i);
		}

		System.out.println("Min of all elements :: " + numbers[0]);
		System.out.println("Max of all elements :: " + numbers[numbers.length - 1]);

	}

}
