package com.citi.main;

import com.citi.exception.InvalidProductPriceException;
import com.citi.pojo.ProductDetails;

public class ProductMain {
	public static void main(String[] args) {
		try {
			ProductDetails details = new ProductDetails();
			details.setProductId(101);
			details.setName("Lux");
			details.setPrice(10);
		} catch (InvalidProductPriceException e) {
			e.printStackTrace();
		}

		try {
			ProductDetails productDetails = new ProductDetails(102, "Nirma", 15);
		} catch (InvalidProductPriceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
