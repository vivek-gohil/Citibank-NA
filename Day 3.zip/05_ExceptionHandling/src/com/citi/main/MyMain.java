package com.citi.main;

public class MyMain {
	public static void main(String[] args) {
		try {
			Class.forName("com.citi.pojo.UserDetails");
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}
}
