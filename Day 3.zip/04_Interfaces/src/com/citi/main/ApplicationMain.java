package com.citi.main;

import com.citi.application.MessageApplication;
import com.citi.service.EmailService;
import com.citi.service.MessageService;
import com.citi.service.SMSMessageService;

public class ApplicationMain {
	public static void main(String[] args) {
		MessageService messageService = new MessageService();
		SMSMessageService smsMessageService = new SMSMessageService();
		EmailService emailService = new EmailService();

		MessageApplication application = new MessageApplication(emailService);

		application.processMessage("ghl_vivek@hotmail.com", "Truptiga@gmail.com", "This is sample email");

	}
}
