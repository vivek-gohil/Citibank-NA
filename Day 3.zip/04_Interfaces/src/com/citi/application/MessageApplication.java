package com.citi.application;

import com.citi.service.MyMessageServiceInterface;

public class MessageApplication {
	private MyMessageServiceInterface messageService;

	public MessageApplication() {

	}

	public MessageApplication(MyMessageServiceInterface messageService) {
		this.messageService = messageService;
	}

	public void processMessage(String to, String from, String message) {
		messageService.sendMessage(to, from, message);
	}

}
