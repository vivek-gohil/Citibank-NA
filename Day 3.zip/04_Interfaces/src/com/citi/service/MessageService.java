package com.citi.service;

public class MessageService implements MyMessageServiceInterface {
	public void sendMessage(String to, String from, String message) {
		System.out.println("Sending Message :: " + message + " , To :: " + to + " From :: " + from);
	}
}
