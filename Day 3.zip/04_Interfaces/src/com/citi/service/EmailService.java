package com.citi.service;

public class EmailService implements MyMessageServiceInterface {
	@Override
	public void sendMessage(String to, String from, String message) {
		System.out.println("Sending Email to :: " + to + " From :: " + from + " Message :: " + message);
	}
}
