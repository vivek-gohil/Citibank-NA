package com.citi.pojo;

public class HP3536 implements PrinterDriver, PrinterPageSetting {
	public void print() {
		System.out.println("HP3536 is printing a documnet");
	}

	@Override
	public void setPageSize() {
		System.out.println("Setting page size as A4");
	}

	@Override
	public void displayInfo() {
		// PrinterPageSetting.super.displayInfo();
		System.out.println("HP3536 is priting details");
	}
}
