package com.citi.pojo;

public class CanonBWD40 implements PrinterDriver {
	public void print() {
		System.out.println("CanonBWD40 is printing document");
	}
}
