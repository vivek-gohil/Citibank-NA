package com.citi.main;

import java.io.File;

import com.citi.util.FileMetadataUtil;

public class FileMetadataMain {

	public static void main(String[] args) {
		FileMetadataUtil fileMetadataUtil = new FileMetadataUtil();

		File file = new File("c:/javafileio/myfile.txt");

		fileMetadataUtil.printMetadata(file);

	}

}
