package com.citi.main;

import java.io.File;

import com.citi.util.FileOutputStreamUtil;

public class FileOutputStreamUtilMain {

	public static void main(String[] args) {
		File file = new File("c:/javafileio/writetest.txt");
		FileOutputStreamUtil fileOutputStreamUtil = new FileOutputStreamUtil(file);

		String data = "This is smaple data for file";

		if (fileOutputStreamUtil.writeFile(data.getBytes())) {
			System.out.println("Please check your file");
			System.out.println(file.getAbsolutePath());
		}
	}

}
