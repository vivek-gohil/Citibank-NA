package com.citi.main;

import java.io.File;

import com.citi.util.FileReaderUtil;

public class FileReaderMain {

	public static void main(String[] args) {

		File file = new File("c:/javafileio/myfile.txt");

		FileReaderUtil readerUtil = new FileReaderUtil(file);

		char[] data = readerUtil.readFile();

		System.out.println("Data in file");

		for (char b : data) {
			System.out.print((char) b);
		}
	}

}
