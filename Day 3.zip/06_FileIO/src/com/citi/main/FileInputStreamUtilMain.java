package com.citi.main;

import java.io.File;

import com.citi.util.FileInputStreamUtil;

public class FileInputStreamUtilMain {

	public static void main(String[] args) {

		File file = new File("c:/javafileio/myfile.txt");

		FileInputStreamUtil fileInputStreamUtil = new FileInputStreamUtil(file);

		byte[] data = fileInputStreamUtil.readFile();

		System.out.println("Data in file");

		for (byte b : data) {
			System.out.print((char)b);
		}
	}

}
