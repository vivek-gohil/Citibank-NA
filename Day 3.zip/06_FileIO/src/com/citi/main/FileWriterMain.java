package com.citi.main;

import java.io.File;

import com.citi.util.FileWriterUtil;

public class FileWriterMain {
	public static void main(String[] args) {
		File file = new File("c:/javafileio/writer.txt");

		String data = "This is for writer testing";

		FileWriterUtil writerUtil = new FileWriterUtil(file);

		if (writerUtil.writeFile(data.toCharArray())) {
			System.out.println("Please check your file");
			System.out.println(file.getAbsolutePath());
		}
	}
}
