package com.citi.main;

import java.io.File;

import com.citi.util.BufferedReaderUtil;

public class BufferReaderMain {
	public static void main(String[] args) {
		File file = new File("c:/javafileio/myfile.txt");

		BufferedReaderUtil bufferedReaderUtil = new BufferedReaderUtil(file);

		String data = bufferedReaderUtil.readFile();

		if (!data.equals("")) {
			System.out.println(data);
		} else {
			System.out.println("Something wnt wrong");
		}
	}
}
