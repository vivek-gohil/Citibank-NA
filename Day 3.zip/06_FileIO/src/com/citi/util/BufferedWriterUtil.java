package com.citi.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class BufferedWriterUtil {
	private Writer writer;
	private File file;

	public BufferedWriterUtil(File file) {
		this.file = file;
	}

	public boolean writeFile(char[] data) {
		try {
			writer = new BufferedWriter(new FileWriter(file));
			writer.write(data);
			return true;
		} catch (IOException e) {
			System.out.println("Exception while writing file");
			System.out.println(e.getMessage());
		} finally {
			try {
				writer.close();
			} catch (IOException e) {
				System.out.println("Exception while closing file");
				System.out.println(e.getMessage());
			}
		}
		return false;

	}
}
