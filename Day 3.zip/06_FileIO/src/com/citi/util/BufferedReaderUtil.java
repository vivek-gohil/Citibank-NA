package com.citi.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderUtil {
	private BufferedReader reader;
	private File file;
	private String data = "";

	public BufferedReaderUtil(File file) {
		this.file = file;
	}

	public String readFile() {
		try {
			reader = new BufferedReader(new FileReader(file));
			String line = reader.readLine();
			while (line != null) {
				data = data + line + "\n";
				line = reader.readLine();
			}
			return data;
		} catch (FileNotFoundException e) {
			System.out.println("Exception while reading file");
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println("Exception while reading file");
			System.out.println(e.getMessage());
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				System.out.println("Exception while closing file");
				System.out.println(e.getMessage());
			}
		}
		return data;
	}
}
