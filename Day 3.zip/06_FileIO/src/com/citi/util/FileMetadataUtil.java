package com.citi.util;

import java.io.File;
import java.util.Date;

public class FileMetadataUtil {
	public void printMetadata(File file) {
		if (file.exists()) {
			System.out.println("File Name :: " + file.getName());
			System.out.println("Location :: " + file.getAbsolutePath());
			System.out.println("Size :: " + file.length() + " bytes");
			System.out.println("CanRead :: " + file.canRead());
			System.out.println("CanWrite :: " + file.canWrite());
			System.out.println("CanExecute :: " + file.canExecute());
			System.out.println("Modified Date :: " + new Date(file.lastModified()));
		} else {
			System.out.println("Invalid File!");
		}
	}
}
