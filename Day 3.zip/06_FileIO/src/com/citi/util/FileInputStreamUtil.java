package com.citi.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class FileInputStreamUtil {
	private InputStream inputStream;
	private byte[] fileData;
	private File file;

	public FileInputStreamUtil(File file) {
		this.file = file;
		fileData = new byte[(int) this.file.length()];
	}

	public byte[] readFile() {
		try {
			inputStream = new FileInputStream(file);
			inputStream.read(fileData);
		} catch (FileNotFoundException e) {
			System.out.println("Exception while reading file");
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println("Exception while reading file");
			System.out.println(e.getMessage());
		} finally {
			try {
				inputStream.close();
			} catch (IOException e) {
				System.out.println("Exception while closing file");
				System.out.println(e.getMessage());
			}
		}
		return fileData;
	}

}
