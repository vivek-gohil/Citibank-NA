package com.citi.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class FileOutputStreamUtil {
	private OutputStream outputStream;
	private File file;

	public FileOutputStreamUtil(File file) {
		this.file = file;
	}

	public boolean writeFile(byte[] data) {
		try {
			outputStream = new FileOutputStream(file);
			outputStream.write(data);
			return true;
		} catch (FileNotFoundException e) {
			System.out.println("Exception while writing file");
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println("Exception while writing file");
			System.out.println(e.getMessage());
		} finally {
			try {
				outputStream.close();
			} catch (IOException e) {
				System.out.println("Exception while closing file");
				System.out.println(e.getMessage());
			}
		}
		return false;
	}
}
