package com.citi.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class FileReaderUtil {
	private Reader reader;
	private char[] data;
	private File file;

	public FileReaderUtil(File file) {
		this.file = file;
		data = new char[(int) file.length()];
	}

	public char[] readFile() {
		try {
			reader = new FileReader(file);
			reader.read(data);
		} catch (FileNotFoundException e) {
			System.out.println("Exception while reading file");
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println("Exception while reading file");
			System.out.println(e.getMessage());
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				System.out.println("Exception while closing reader");
				System.out.println(e.getMessage());
			}
		}
		return data;
	}

}
