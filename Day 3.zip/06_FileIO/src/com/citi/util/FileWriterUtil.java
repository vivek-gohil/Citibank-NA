package com.citi.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class FileWriterUtil {
	private Writer writer;
	private File file;

	public FileWriterUtil(File file) {
		this.file = file;
	}

	public boolean writeFile(char[] data) {
		try {
			writer = new FileWriter(file);
			writer.write(data);
			return true;
		} catch (IOException e) {
			System.out.println("Exception while writing file");
			System.out.println(e.getMessage());
		} finally {
			try {
				writer.close();
			} catch (IOException e) {
				System.out.println("Exception while closing file");
				System.out.println(e.getMessage());
			}
		}
		return false;
	}
}
